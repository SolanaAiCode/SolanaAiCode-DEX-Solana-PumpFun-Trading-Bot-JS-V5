import { CodeMirror } from "./edit/main.js"

export default CodeMirror
